/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import FadingVideo from './components/FadingVideo';
import BlurText from './components/BlurText';
import { motion } from 'motion/react';
import { ArrowUpRight, Play, Clock, Globe } from 'lucide-react';

export default function App() {
  return (
    <div className="bg-black text-white font-body min-h-screen">
      {/* Navbar */}
      <nav className="fixed top-4 left-0 w-full px-8 lg:px-16 z-50 flex justify-between items-center">
        <div className="liquid-glass rounded-full w-12 h-12 flex items-center justify-center font-heading italic text-xl">a</div>
        <div className="hidden md:flex liquid-glass rounded-full px-1.5 py-1.5 gap-1">
          {['Home', 'Voyages', 'Worlds', 'Innovation', 'Plan Launch'].map((link) => (
            <a key={link} href="#" className="px-3 py-2 text-sm font-medium text-white/90">
              {link}
            </a>
          ))}
          <button className="bg-white text-black px-4 py-2 rounded-full text-sm font-medium flex items-center gap-1 whitespace-nowrap">
            Claim a Spot <ArrowUpRight className="h-4 w-4" />
          </button>
        </div>
        <div className="w-12 h-12" />
      </nav>

      {/* Hero Section */}
      <section className="relative h-screen w-full overflow-hidden">
        <FadingVideo
          src="https://github.com/weixubo281-code/davidweb02/raw/refs/heads/main/file1779281488099_351680.mp4"
          className="absolute left-1/2 top-0 -translate-x-1/2 object-cover object-top z-0"
          style={{ width: '120%', height: '120%' }}
        />
        <div className="relative z-10 flex flex-col items-center justify-center h-full px-4 pt-24">
          <motion.div initial={{ filter: 'blur(10px)', opacity: 0, y: 20 }} animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }} transition={{ delay: 0.4, duration: 0.8 }} className="liquid-glass rounded-full px-1 py-1 flex items-center gap-2">
            <span className="bg-white text-black rounded-full px-3 py-1 text-xs font-semibold">New</span>
            <span className="text-sm text-white/90 pr-3">Maiden Crewed Voyage to Mars Arrives 2026</span>
          </motion.div>
          
          <BlurText text="Venture Past Our Sky Across the Universe" className="text-6xl md:text-7xl lg:text-[5.5rem] font-heading italic text-white leading-[0.8] max-w-2xl text-center mt-6 tracking-[-4px]" />
          
          <motion.p initial={{ filter: 'blur(10px)', opacity: 0, y: 20 }} animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }} transition={{ delay: 0.8, duration: 0.8 }} className="mt-4 text-sm md:text-base text-white max-w-2xl text-center font-light leading-tight">
            Discover the universe in ways once unimaginable. Our pioneering vessels and breakthrough engineering bring deep-space exploration within reach—secure and extraordinary.
          </motion.p>
          
          <motion.div initial={{ filter: 'blur(10px)', opacity: 0, y: 20 }} animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }} transition={{ delay: 1.1, duration: 0.8 }} className="flex items-center gap-6 mt-6">
            <button className="liquid-glass-strong rounded-full px-5 py-2.5 text-sm font-medium text-white flex items-center gap-2">
              Start Your Voyage <ArrowUpRight className="h-5 w-5" />
            </button>
            <a href="#" className="text-white flex items-center gap-2">
              <Play className="h-4 w-4 fill-white" /> View Liftoff
            </a>
          </motion.div>

          <motion.div initial={{ filter: 'blur(10px)', opacity: 0, y: 20 }} animate={{ filter: 'blur(0px)', opacity: 1, y: 0 }} transition={{ delay: 1.3, duration: 0.8 }} className="flex items-stretch gap-4 mt-8">
            <div className="liquid-glass p-5 w-[220px] rounded-[1.25rem]">
              <Clock className="h-7 w-7 text-white" />
              <div className="text-4xl front-heading italic mt-2 tracking-[-1px]">34.5 Min</div>
              <div className="text-xs text-white font-light mt-1">Average Videos Watch Time</div>
            </div>
            <div className="liquid-glass p-5 w-[220px] rounded-[1.25rem]">
              <Globe className="h-7 w-7 text-white" />
              <div className="text-4xl front-heading italic mt-2 tracking-[-1px]">2.8B+</div>
              <div className="text-xs text-white font-light mt-1">Users Across the Globe</div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Capabilities Section */}
      <section className="relative min-h-screen w-full pt-24 pb-10 px-8 md:px-16 lg:px-20 flex flex-col">
        <FadingVideo
          src="https://github.com/weixubo281-code/davidweb02/raw/refs/heads/main/file1779281488099_351680.mp4"
          className="absolute inset-0 w-full h-full object-cover z-0"
        />
        <div className="relative z-10 flex flex-col flex-1">
          <div className="mb-auto">
            <p className="text-sm text-white/80 mb-6">// Capabilities</p>
            <h2 className="font-heading italic text-white text-6xl md:text-7xl lg:text-[6rem] leading-[0.9] tracking-[-3px]">
              Production<br/>evolved
            </h2>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16 pb-10">
            {[
              { title: 'AI Scenery', body: 'AI analyzes your product to create indistinguishable natural environments — from Icelandic cliffs to misty forests.', tags: ['Natural Context', 'Photo Realism', 'Infinite Settings', 'Eco-Vibe'] },
              { title: 'Batch Production', body: 'Style your entire product line in minutes. Create a unified visual identity for catalogues and social media without weeks of retouching.', tags: ['Scale Fast', 'Visual Consistency', 'Time Saver', 'Ready to Post'] },
              { title: 'Smart Lighting', body: 'Automatic lighting and material adjustment. Achieve flawless integration with realistic shadows and sunlight.', tags: ['Ray Tracing', 'Physical Shadows', 'Studio Quality', 'Sunlight Sync'] }
            ].map((card, i) => (
              <div key={i} className="liquid-glass rounded-[1.25rem] p-6 min-h-[360px] flex flex-col">
                <div className="flex items-start justify-between gap-4">
                  <div className="p-3 liquid-glass rounded-[0.75rem]">
                    {/* Simplified icon representation for now */}
                    <div className="h-6 w-6 bg-white/20 rounded-sm" />
                  </div>
                  <div className="flex flex-wrap justify-end gap-1.5 max-w-[70%]">
                    {card.tags.map(tag => (
                      <span key={tag} className="liquid-glass rounded-full px-3 py-1 text-[11px] text-white/90 whitespace-nowrap">{tag}</span>
                    ))}
                  </div>
                </div>
                <div className="flex-1" />
                <h3 className="font-heading italic text-white text-3xl md:text-4xl tracking-[-1px] leading-none mt-6">{card.title}</h3>
                <p className="mt-3 text-sm text-white/90 font-light leading-snug max-w-[32ch]">{card.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
