import { useEffect, useRef } from 'react';

interface FadingVideoProps {
  src: string;
  className?: string;
  style?: React.CSSProperties;
}

export default function FadingVideo({ src, className, style }: FadingVideoProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const opacityRef = useRef(0);
  const fadingOutRef = useRef(false);
  const rAFRef = useRef<number>();

  const FADE_MS = 500;
  const FADE_OUT_LEAD = 0.55;

  const fadeTo = (target: number, duration: number) => {
    if (rAFRef.current) cancelAnimationFrame(rAFRef.current);
    const start = performance.now();
    const startOpacity = opacityRef.current;
    const delta = target - startOpacity;

    const animate = (now: number) => {
      const elapsed = now - start;
      const progress = Math.min(elapsed / duration, 1);
      const newOpacity = startOpacity + delta * progress;
      
      opacityRef.current = newOpacity;
      if (videoRef.current) videoRef.current.style.opacity = String(newOpacity);

      if (progress < 1) {
        rAFRef.current = requestAnimationFrame(animate);
      }
    };
    rAFRef.current = requestAnimationFrame(animate);
  };

  useEffect(() => {
    const video = videoRef.current;
    if (!video) return;

    const handleLoadedData = () => {
      video.style.opacity = '0';
      opacityRef.current = 0;
      video.play();
      fadeTo(1, FADE_MS);
    };

    const handleTimeUpdate = () => {
      if (!fadingOutRef.current && video.duration - video.currentTime <= FADE_OUT_LEAD && video.duration - video.currentTime > 0) {
        fadingOutRef.current = true;
        fadeTo(0, FADE_MS);
      }
    };

    const handleEnded = () => {
      video.style.opacity = '0';
      opacityRef.current = 0;
      fadingOutRef.current = false;
      setTimeout(() => {
        video.currentTime = 0;
        video.play();
        fadeTo(1, FADE_MS);
      }, 100);
    };

    video.addEventListener('loadeddata', handleLoadedData);
    video.addEventListener('timeupdate', handleTimeUpdate);
    video.addEventListener('ended', handleEnded);

    return () => {
      if (rAFRef.current) cancelAnimationFrame(rAFRef.current);
      video.removeEventListener('loadeddata', handleLoadedData);
      video.removeEventListener('timeupdate', handleTimeUpdate);
      video.removeEventListener('ended', handleEnded);
    };
  }, []);

  return (
    <video
      ref={videoRef}
      src={src}
      className={className}
      style={{ ...style, opacity: 0 }}
      autoPlay
      muted
      playsInline
      preload="auto"
    />
  );
}
